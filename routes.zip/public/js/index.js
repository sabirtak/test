function predict(){
    $('select').children('option').remove();
    $('select').selectpicker('refresh');
    var data = document.getElementById("name").value;
    document.getElementById('sample').innerHTML="";
    $.get("/contacts/search/"+data, function(contacts, status){
        if(status === "success")
        {
            for(contact of contacts)
            {
                document.getElementById('sample').innerHTML+= "</br>"+contact.name;
                $("select").append(`<option value='${contact.name}'>${contact.name}</option>`);
                $('select').selectpicker('refresh');
            }
        }
    });
}
function getView(){
    var string = $('select').find(":selected").text();
    console.log(string);
    if(string===""|| string===null)
    {
        document.getElementById('sample').innerHTML="Nothing Selected";
    }
    else{
    $.get("/contacts/search/"+string, function(contacts, status){
        if(status === "success")
        {
            var html = `<div class="container">
            <h2>Contacts</h2>
            <hr/>
            <table class="table table-hover table-bordered">
            <thead></thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Type</th>
                <th></th>
            </tr>
            <tbody>`;
            for(contact of contacts)
            {
                html +=`
                        <tr>
                            <td>${contact.name}</td>
                            <td>${contact.email}</td>
                            <td>${contact.mobile}</td>
                            <td>${contact.type}</td>
                            <td>
                                <a href="/contacts/update/${contact._id}",class="btn btn-warning">
                                    <span class="glyphicon glyphicon-pencil"></span>
                                </a>
                                <a href="/contacts/delete/${contact._id}",class="btn btn-warning">
                                    <span class="glyphicon glyphicon-remove"></span>
                                </a>
                            </td>
                        </tr>`;
            }
            html+="</tbody></table></div>";
            document.getElementById('sample').innerHTML=html;
        }
    });
}
}
function gettype(){
    document
}