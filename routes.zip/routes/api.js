var router = require('express').Router();
var contacts = require('../models/contacts');

router.get("/",function(req,res){
    contacts.find(function(err,docs){
        if(err) res.json(err);
        else res.json(docs);
    })
})
router.get("/search/:name",function(req,res){
    var regex = new RegExp(req.params.name, 'i');
    var query = contacts.find({ name: regex }).sort({ "updated_at": -1 }).sort({ "created_at": -1 }).limit(10);

    // Execute query in a callback and return users list
    query.exec(function (err, docs) {
        if (!err) {
            // Method to construct the json result set
            res.json(docs)
        } else res.json(err);
    });
})
router.get("/:id", function (req, res) {
    contacts.findById(req.params.id, function (err, data) {
        if (err) res.json(err);
        else res.json(data);
    })
})
router.put('/', function (req, res, next) {
    var contact = new contacts(req.body);
    contact.save(function (err, data) {
        if(err) res.json(err);
        else res.json(data);
    });
});
router.post('/:id', function (req, res, next) {
  contacts.findByIdAndUpdate({_id:req.params.id},req.body,function(err,data){
      if(err) res.json(err);
      else res.json(data);
  })
});
router.delete("/:id", function (req, res) {
    contacts.findByIdAndRemove(req.params.id,function(err,data){
        if(err) res.json(err);
        else res.json(data);
    })
})
module.exports.router = router;