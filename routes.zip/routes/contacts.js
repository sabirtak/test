var router = require('express').Router();
var contacts = require('../models/contacts');

//Search Contact
router.get('/search/:query', function(req, res,next) {
    var regex = new RegExp(req.params.query, 'i');
    var query = contacts.find({name: regex}).sort({"updated_at":-1}).sort({"created_at":-1}).limit(20);
         
       // Execute query in a callback and return users list
   query.exec(function(err, docs) {
       if (!err) {
          // Method to construct the json result set
          res.json(docs)
       } else console.log(err);
    });
 });
 //Render Search Page
 router.get('/',function(req,res,next){
     res.render('search');
 })
 //Search Logic For Displaying Table

 router.get('/search',function(req,res,next){
    res.render('searchbytype');
 });
 router.post('/search/type',function(req,res,next){
   contacts.find({type:req.body.type},function(err,data){
       res.render('view',{contacts:data});
   })
 });
 router.post('/search',function(req,res,next){
    res.render('searchbytype');
 });

//update Rendered Page
router.get('/update/:id', function (req, res, next) {
    contacts.find({ _id: req.params.id }, function (err, docs) {
        if (err) console.log("Error Whole getting results from db");
        else {
            res.render('update', { title: "Edit Contact", contacts: docs });
        }
    });
});
//update Logic 
router.post('/update/:id', function (req, res, next) {
    contacts.findByIdAndUpdate({ _id: req.params.id }, {
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        type: req.body.type
    }, function (err, data) {
        if (err) console.log("Error Occured while updating data : " + err);
        else {
            res.redirect('/contacts/view');
        }
    })
});
//Delete Contact Logic
router.get('/delete/:id', function (req, res, next) {
    contacts.findByIdAndRemove(req.params.id, function (err, data) {
        if (err) console.log("Error while deleting : " + err);
        else {
            res.redirect('/contacts/view');
        }
    });
});
//View Contacts Rendered Page
router.get('/view', function (req, res, next) {
    contacts.find(function (err, docs) {
        if (err) console.log("Error Occurred while finding : " + err);
        else {
            //console.log(docs);
            res.render('view', { title: "View Contacts", contacts: docs });
        }
    });
});
//Add Contact Page Rendered Page
router.get('/add', function (req, res, next) {
    res.render('add', { title: "Add Contacts" });
});
//Add Contact Logic
router.post('/add', function (req, res, next) {
    var contact = new contacts({
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        type: req.body.type
    });
    contact.save(function (err, data) {
        if (err) console.log("Error While inserting data : " + err);
        else {
            res.redirect('/contacts/view');
        }
    });
});

module.exports.router = router;