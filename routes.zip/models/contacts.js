var mongoose=require('mongoose');

var schema = mongoose.Schema;

var contacts = new schema(
    {
        name:{type:String,required:true},
        email:{type:String,required:true},
        mobile:{type:Number,required:true},
        type:{type:String,required:true}
    }
)
module.exports=mongoose.model('contacts',contacts);