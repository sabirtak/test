var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var path =require('path');

var indexRoutes = require('../routes/index').router;
var apiRoutes = require('../routes/api').router;
var contactRoutes = require('../routes/contacts').router;


var app = express();

app.use(express.static(path.join(__dirname , '../public')));

app.set('port',process.env.PORT || 5000);
app.set('view engine','jade');
app.set('mongoHost',"localhost");
app.set('mongoPort',27017);
app.set('mongoDbName',"ContactDB");

app.use(bodyParser());
app.use(bodyParser({extended:true}));

app.use('/',indexRoutes);
app.use('/api', apiRoutes);
app.use('/contacts',contactRoutes);


mongoose.connect(`mongodb://${app.get('mongoHost')}:${app.get('mongoPort')}/${app.get('mongoDbName')}`);
mongoose.connection.on('connected',function(){
    console.log(`Connected to host : ${app.get('mongoHost')} on Port : ${app.get('mongoPort')} and using DB : ${app.get('mongoDbName')}`);
});
mongoose.connection.on('error',function(err){
    console.log(`Cannot Connect to Mongo Server : ${err}`);
});

app.listen(app.get('port'),function(){
    console.log("Server started on http://localhost:"+app.get('port'));
})