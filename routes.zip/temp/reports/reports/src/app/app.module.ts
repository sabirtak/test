import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChartModule as AngularChart } from 'angular-highcharts';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { MaterialdesignComponent } from './components/materialdesign/materialdesign.component';
import { TreemapComponent } from './components/treemap/treemap.component';
import { ProgressBarComponent } from './components/progress-bar/progress-bar.component';
import { ScoreSpeedometerComponent } from './components/score-speedometer/score-speedometer.component';
import { UsersTableComponent } from './components/users-table/users-table.component';
export declare var require: any;

export function highchartsFactory() {
  const hc = require('highcharts/highstock');
  const dd = require('highcharts/modules/exporting');
  dd(hc);
  return hc;
}

@NgModule({
  declarations: [
    AppComponent,
    MaterialdesignComponent,
    TreemapComponent,
    ProgressBarComponent,
    ScoreSpeedometerComponent,
    UsersTableComponent
  ],
  imports: [
    BrowserModule,
    AngularChart,
    ChartModule
    .forRoot(require('highcharts'),
    require('highcharts/highcharts-3d'),
    require('highcharts/modules/wordcloud'),
    require('highcharts/modules/data'),
    require('highcharts/modules/drilldown'),
    require('highcharts/modules/treemap'),
    require('highcharts/modules/heatmap'),
    require('highcharts/highcharts-more'),
    require('highcharts/modules/solid-gauge')
    )
      
  ],
  providers: [
    // {
    //   provide: HighchartsStatic,
    //   useFactory: highchartsFactory
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
 