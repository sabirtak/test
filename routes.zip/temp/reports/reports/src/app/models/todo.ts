export class Todo {
    taskname: string;
    status: string;
}