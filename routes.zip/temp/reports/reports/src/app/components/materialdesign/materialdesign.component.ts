import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materialdesign',
  templateUrl: './materialdesign.component.html',
  styleUrls: ['./materialdesign.component.css']
})
export class MaterialdesignComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
