import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScoreSpeedometerComponent } from './score-speedometer.component';

describe('ScoreSpeedometerComponent', () => {
  let component: ScoreSpeedometerComponent;
  let fixture: ComponentFixture<ScoreSpeedometerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScoreSpeedometerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScoreSpeedometerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
