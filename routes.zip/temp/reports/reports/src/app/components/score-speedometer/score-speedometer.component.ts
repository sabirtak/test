import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-score-speedometer',
  templateUrl: './score-speedometer.component.html',
  styleUrls: ['./score-speedometer.component.css']
})
export class ScoreSpeedometerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
