import { Component } from '@angular/core';
import { Chart } from 'angular-highcharts';
import { Highcharts } from 'angular-highcharts';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  current: number = 25;
  max: number = 50;
  stroke: number = 15;
  radius: number = 125;
  rounded: boolean = true;
  responsive: boolean = false;
  clockwise: boolean = true;
  color: string = '#45ccce';
  background: string = '#eaeaea';
  duration: number = 800;
  animation: string = 'easeOutCubic';
  animationDelay: number = 0;
  animations: string[] = [];
  gradient: boolean = false;
  realCurrent: number = 0;
  private percent
  private status
  constructor() {
    this.percent = 80;
    this.status = 'Delay'
  }
  
}

