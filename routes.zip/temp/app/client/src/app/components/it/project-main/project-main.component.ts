import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'project-main',
  templateUrl: './project-main.component.html',
  styleUrls: ['./project-main.component.css']
})
export class ProjectMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  tempFunc(){
    alert("click");
  }
  addRow(){
    $("tbody").append(`
      <tr>
        <td><a class="waves-effect waves-light  modal-trigger" href="#modal1">Some Applications</a>
        </td>
        <td>
          <a class="modal-trigger" href="#modal1" (click)="tempFunc()">
            <div id="progressbar">
              <div id="bar" style="width:0%" class="blue"></div>
              <div id="label" class="blue-text">0%</div>
            </div>
          </a>
        </td>
        <td>
          <div id="progressbar">
            <div id="bar" style="width:0%" class="blue"></div>
            <div id="label" class="blue-text">0%</div>
          </div>
        </td>
        <td>
          <div id="progressbar">
            <div id="bar" style="width:0%" class="blue"></div>
            <div id="label" class="blue-text">0%</div>
          </div>
        </td>
        <td>
          <div id="progressbar">
            <div id="bar" style="width:0%" class="blue"></div>
            <div id="label" class="blue-text">0%</div>
          </div>
        </td>
        <td>
          <div id="progressbar">
            <div id="bar" style="width:0%" class="blue"></div>
            <div id="label" class="blue-text">0%</div>
          </div>
        </td>
         <td>
            <div id="progressbar">
              <div id="label" class="blue-text">Scores</div>
            </div>
          </td>
      </tr>
    `)
  }
}
