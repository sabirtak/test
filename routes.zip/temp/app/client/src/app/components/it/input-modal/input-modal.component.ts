import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'input-modal',
  templateUrl: './input-modal.component.html',
  styleUrls: ['./input-modal.component.css']
})
export class InputModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
