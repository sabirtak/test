import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
// import { MaterialModule } from '@angular/material';
import { MaterialModule } from './modules/material/material.module';
import { MatSnackBarComponent } from './components/mat-snack-bar/mat-snack-bar.component';
import { FormsModule, FormBuilder } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { ProjectMainComponent } from './components/it/project-main/project-main.component';
import { InputModalComponent } from './components/IT/input-modal/input-modal.component';
// import { MatSnackBarComponent } from './components/mat-snack-bar/mat-snack-bar.component';

@NgModule({
  declarations: [
    AppComponent,
    MatSnackBarComponent,
    ProjectMainComponent,
    InputModalComponent,
    // MatSnackBarComponent  
  ],
  imports: [
    ChartsModule,
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule, 
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
