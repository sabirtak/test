import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import chart.js 
import { ChartsModule as ng2Charts } from 'ng2-charts/ng2-charts';
//import for highcharts
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
export declare var require: any;

import { AppComponent } from './app.component';
import { ForAProjectComponent } from './components/for-a-project/for-a-project.component';
import { CompletionTileComponent } from './components/for-a-project/completion-tile/completion-tile.component';
import { BusinessCriticalityComponent } from './components/for-a-project/business-criticality/business-criticality.component';
import { CountryBubbleComponent } from './components/for-a-project/country-bubble/country-bubble.component';
import { UiBarChartComponent } from './components/for-a-project/ui-bar-chart/ui-bar-chart.component';
import { ScoreGaugeComponent } from './components/for-a-project/score-gauge/score-gauge.component';
import { ScoreCompletionComponent } from './components/for-a-project/score-completion/score-completion.component';

export function highchartsFactory() {
  const hc = require('highcharts/highstock');
  const dd = require('highcharts/modules/exporting');
  dd(hc);
  return hc;
}

@NgModule({
  declarations: [
    AppComponent,
    ForAProjectComponent,
    CompletionTileComponent,
    BusinessCriticalityComponent,
    CountryBubbleComponent,
    UiBarChartComponent,
    ScoreGaugeComponent,
    ScoreCompletionComponent,

  ],
  imports: [
    BrowserModule,
    ng2Charts,
    ChartModule
      .forRoot(require('highcharts'),
      require('highcharts/highcharts-3d'),
      require('highcharts/highcharts-more'),
      require('highcharts/modules/wordcloud'),
      require('highcharts/modules/data'),
      require('highcharts/modules/drilldown'),
      require('highcharts/modules/funnel'),
      require('highcharts/modules/solid-gauge'))

  ],
  providers: [
    // {
    //   provide: HighchartsStatic,
    //   useFactory: highchartsFactory
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
