import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForAProjectComponent } from './for-a-project.component';

describe('ForAProjectComponent', () => {
  let component: ForAProjectComponent;
  let fixture: ComponentFixture<ForAProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForAProjectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForAProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
