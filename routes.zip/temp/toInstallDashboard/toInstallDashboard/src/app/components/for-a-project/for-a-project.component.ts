import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-a-project',
  templateUrl: './for-a-project.component.html',
  styleUrls: ['./for-a-project.component.css']
})
export class ForAProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
